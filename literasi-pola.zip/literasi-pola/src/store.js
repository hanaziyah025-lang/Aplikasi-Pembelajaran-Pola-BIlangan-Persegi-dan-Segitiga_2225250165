// Simpan hasil ke Supabase bila .env diisi; jika tidak, ke localStorage.
import { createClient } from '@supabase/supabase-js'
const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY
const sb = url && key ? createClient(url, key) : null

export async function saveAttempt(rec) {
  const all = JSON.parse(localStorage.getItem('attempts') || '[]')
  all.push({ ...rec, at: new Date().toISOString() })
  localStorage.setItem('attempts', JSON.stringify(all))
  if (sb) { try { await sb.from('attempts').insert(rec) } catch (e) { console.warn(e) } }
}
export const loadAttempts = (kode) =>
  JSON.parse(localStorage.getItem('attempts') || '[]').filter((a) => a.kode === kode)
