import { useState } from 'react'
import Pattern3D from './Pattern3D.jsx'
import { materi, soal } from './data.js'
import { saveAttempt, loadAttempts } from './store.js'

export default function App() {
  const [kode, setKode] = useState(localStorage.getItem('kode') || '')
  const [layar, setLayar] = useState(kode ? 'home' : 'login')
  const masuk = (k) => { localStorage.setItem('kode', k); setKode(k); setLayar('home') }
  return (
    <main className="app">
      {layar === 'login' && <Login onMasuk={masuk} />}
      {layar === 'home' && <Home kode={kode} go={setLayar} keluar={() => { localStorage.removeItem('kode'); setKode(''); setLayar('login') }} />}
      {layar === 'materi' && <Materi back={() => setLayar('home')} />}
      {layar === 'latihan' && <Latihan kode={kode} daftar={soal.filter((s) => s.tipe === 'latihan')} back={() => setLayar('home')} />}
      {layar === 'literasi' && <Latihan kode={kode} daftar={soal.filter((s) => s.tipe === 'literasi')} back={() => setLayar('home')} />}
    </main>
  )
}

function Login({ onMasuk }) {
  const [v, setV] = useState('')
  const ok = /^[A-Za-z0-9]{3,10}$/.test(v)
  return (
    <section className="card">
      <h1>Pola Bilangan</h1>
      <p>Masukkan kode siswa dari gurumu.</p>
      <input value={v} onChange={(e) => setV(e.target.value.toUpperCase())} placeholder="Contoh: S01" inputMode="text" />
      <button disabled={!ok} onClick={() => onMasuk(v)}>Masuk</button>
    </section>
  )
}

function Home({ kode, go, keluar }) {
  const skor = loadAttempts(kode).reduce((a, b) => a + (b.skor || 0), 0)
  return (
    <section className="card">
      <h1>Halo, {kode} 👋</h1>
      <p>Skor kamu: <b>{skor}</b></p>
      <button onClick={() => go('materi')}>📘 Belajar Materi</button>
      <button onClick={() => go('latihan')}>✏️ Latihan Pola</button>
      <button onClick={() => go('literasi')}>🧠 Soal Cerita (Literasi)</button>
      <button className="ghost" onClick={keluar}>Ganti kode</button>
    </section>
  )
}

function Materi({ back }) {
  const [i, setI] = useState(0)
  const m = materi[i]
  const [n, setN] = useState(m.n)
  const pindah = (j) => { setI(j); setN(materi[j].n) }
  return (
    <section className="card">
      <h2>{m.judul}</h2>
      <Pattern3D type={m.type} n={n} />
      <label className="slider">Gambar ke-{n}
        <input type="range" min="1" max="8" value={n} onChange={(e) => setN(+e.target.value)} />
      </label>
      <p className="rumus">{m.rumus(n)}</p>
      <p>{m.teks}</p>
      <nav className="row">
        <button className="ghost" disabled={i === 0} onClick={() => pindah(i - 1)}>← Ulangi</button>
        {i < materi.length - 1 ? <button onClick={() => pindah(i + 1)}>Lanjut →</button> : <button onClick={back}>Selesai</button>}
      </nav>
    </section>
  )
}

function Latihan({ kode, daftar, back }) {
  const [i, setI] = useState(0)
  const [tandai, setTandai] = useState({})
  const [jwb, setJwb] = useState('')
  const [hint, setHint] = useState(0)
  const [status, setStatus] = useState(null) // null | 'salah' | 'benar'
  const [alasan, setAlasan] = useState('')
  const s = daftar[i]
  if (!s) return <section className="card"><h2>Selesai 🎉</h2><button onClick={back}>Kembali</button></section>

  const cek = () => {
    const benar = Number(jwb) === s.jawab
    setStatus(benar ? 'benar' : 'salah')
    if (benar) saveAttempt({ kode, soal_id: s.id, skor: Math.max(1, 3 - hint), hint_dipakai: hint })
  }
  const lanjut = () => { setI(i + 1); setJwb(''); setHint(0); setStatus(null); setAlasan(''); setTandai({}) }

  return (
    <section className="card">
      <small>{s.indikator || 'Latihan'} · soal {i + 1}/{daftar.length}</small>
      <Pattern3D type={s.visual.type} n={s.visual.n} />
      <div className="konteks">
        {s.konteks.map((k, idx) => (
          <p key={idx} className={tandai[idx] ? 'mark' : ''} onClick={() => setTandai({ ...tandai, [idx]: !tandai[idx] })}>{k}</p>
        ))}
        <small>Ketuk kalimat untuk menandai informasi penting.</small>
      </div>
      <h3>{s.tanya}</h3>
      <input type="number" inputMode="numeric" value={jwb} onChange={(e) => setJwb(e.target.value)} disabled={status === 'benar'} placeholder="Jawabanmu" />
      {status !== 'benar' && <button disabled={jwb === ''} onClick={cek}>Cek</button>}
      {status === 'salah' && <p className="warn">Belum tepat. Coba lagi, atau minta petunjuk.</p>}
      {status !== 'benar' && hint < s.hints.length && <button className="ghost" onClick={() => setHint(hint + 1)}>💡 Petunjuk ({hint}/{s.hints.length})</button>}
      {s.hints.slice(0, hint).map((h, k) => <p key={k} className="hint">💡 {h}</p>)}
      {status === 'benar' && (
        <div className="ok">
          <p>✅ Benar! Langkahnya:</p>
          <ol>{s.langkah.map((l, k) => <li key={k}>{l}</li>)}</ol>
          <textarea value={alasan} onChange={(e) => setAlasan(e.target.value)} placeholder="Mengapa jawabanmu masuk akal? (boleh dilewati)" />
          <button onClick={lanjut}>Lanjut →</button>
        </div>
      )}
      <button className="ghost" onClick={back}>Kembali</button>
    </section>
  )
}
