# Literasi Pola Bilangan (SMP) – React + Vite + Three.js
## Jalankan
1. Pasang Node.js (LTS) dari nodejs.org
2. Di terminal VS Code: `npm install` lalu `npm run dev`
3. Buka alamat yang tampil (mis. http://localhost:5173). Di HP Android (WiFi sama) buka alamat "Network".
## Supabase (opsional)
Salin `.env.example` jadi `.env`, isi URL dan anon key. Buat tabel:
`create table attempts(id bigint generated always as identity primary key, kode text, soal_id text, skor int, hint_dipakai int, created_at timestamptz default now());`
Tanpa `.env`, data tersimpan di localStorage.
## Deploy
Unggah ke GitHub, impor di vercel.com (gratis) → dapat link. Di Chrome Android: menu ⋮ → Tambahkan ke layar utama.
